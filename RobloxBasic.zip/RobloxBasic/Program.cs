﻿using RobloxBasic.ClientBase.Keybinds;
using RobloxBasic.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RobloxBasic
{
    class Program
    {
        public static EventHandler<EventArgs> mainLoop;

        static void Main(string[] args)
        {
            KeybindHandler kh = new KeybindHandler(); // setup handlers

            MCM.openWindowHost();
            MCM.m.OpenRoblox();

            RobloxThread.onStart(); // invoke onStart

            while (true) // Loop lmao
            {
                try // catch & ignore errors
                {
                    mainLoop.Invoke(null, new EventArgs()); // invoke all key event checks etc
                    RobloxThread.onTick(); // invoke onTick()
                    // Thread.Sleep(1);
                }
                catch
                {

                }
            }
        }
    }
}
